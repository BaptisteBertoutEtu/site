package main.java.fr.univlille.model.board;

public class LabyPredef {
    
    //10x9
    public static boolean[][] petitLaby(){
        return new boolean[][]{
            {true,true,false,false,false,false,false,false,true,true},
            {true ,true ,true ,true ,true ,true ,true ,true ,true ,false},
            {false,false,false,false,false,false,false,false,true ,false},
            {false,true ,true ,true ,false,true ,true ,true ,true ,false},
            {false,true ,false,true ,false,true ,false,false,true ,false},
            {false,true ,false,true ,false,true ,false,true ,true ,false},
            {false,true ,false,true ,false,true ,false,true ,false,false},
            {true,true ,false,true ,true ,true ,false,true ,true ,true },
            {true,false,false,false,false,false,false,false,false,true}
        };
    }
    
    //15x15
    public static boolean[][] moyenLab(){
        return new boolean[][]{
            {true,true,false,false,false,false,false,false,false,false,false,false,false,true,true},
            {true ,true ,true ,true ,false,true ,true ,true ,true ,true ,false,true ,true ,true ,true},
            {false,true ,false,true ,false,true ,false,false,false,true ,false,false,false,true ,false},
            {false,true ,false,true ,false,true ,true ,true ,false,true ,true ,true ,true ,true ,false},
            {false,true ,false,true ,false,true ,false,false,false,false,false,false,false,false,false},
            {false,true ,false,true ,true ,true ,true ,true ,true ,true ,false,true ,true ,true ,false},
            {false,false,false,false,false,false,false,false,false,true ,false,true ,false,false,false},
            {false,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,false},
            {false,true ,false,false,false,false,false,false,false,false,false,true ,false,false,false},
            {false,true ,true ,true ,true ,true ,false,true ,true ,true ,false,true ,true ,true ,false},
            {false,true ,false,false,false,false,false,true ,false,true ,false,true ,false,false,false},
            {false,true ,true ,true ,false,true ,true ,true ,false,true ,false,true ,true ,true ,false},
            {false,false,false,true ,false,true ,false,false,false,false,false,false,false,true ,false},
            {true,true ,true ,true ,false,true ,true ,true ,true ,true ,true ,true ,true ,true ,true },
            {true,true,false,false,false,false,false,false,false,false,false,false,false,false,true}
        };
    }

    //30x20
    public static boolean[][] grandLab(){
        return new boolean[][]{
            {true ,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,true },
            {true ,true ,false,true ,true ,true ,false,true ,false,true ,true ,true ,true ,true ,true ,true ,true ,true ,false,true ,true ,true ,false,true ,true ,true ,false,true ,true },
            {false,true ,false,true ,false,true ,false,true ,false,true ,false,false,false,false,false,false,false,true ,false,true ,false,true ,false,false,false,true ,false,true ,false},
            {false,true ,false,true ,false,true ,true ,true ,false,true ,false,true ,true ,true ,true ,true ,false,true ,false,true ,false,true ,true ,true ,true ,true ,false,true ,false},
            {false,true ,false,true ,false,false,false,true ,false,true ,false,true ,false,true ,false,true ,false,true ,false,true ,false,false,false,true ,false,false,false,true ,false},
            {false,true ,true ,true ,false,true ,false,true ,true ,true ,false,true ,false,true ,false,true ,false,true ,false,true ,true ,true ,false,true ,true ,true ,false,true ,false},
            {false,false,false,false,false,true ,false,true ,false,false,false,true ,false,false,false,true ,false,true ,false,false,false,true ,false,false,false,true ,false,true ,false},
            {false,true ,false,true ,true ,true ,false,true ,true ,true ,true ,true ,false,true ,true ,true ,false,true ,true ,true ,false,true ,false,true ,true ,true ,false,true ,false},
            {false,true ,false,true ,false,false,false,false,false,false,false,true ,false,true ,false,false,false,false,false,false,false,true ,false,true ,false,false,false,true ,false},
            {false,true ,false,true ,true ,true ,true ,true ,true ,true ,false,true ,false,true ,true ,true ,true ,true ,true ,true ,true ,true ,false,true ,true ,true ,true ,true ,false},
            {false,true ,false,false,false,false,false,false,false,true ,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,true ,false},
            {false,true ,false,true ,true ,true ,true ,true ,true ,true ,false,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,false},
            {false,true ,false,true ,false,false,false,false,false,true ,false,true ,false,false,false,false,false,true ,false,false,false,false,false,false,false,true ,false,false,false},
            {false,true ,true ,true ,false,true ,true ,true ,false,true ,true ,true ,false,true ,true ,true ,false,true ,false,true ,true ,true ,true ,true ,false,true ,false,true ,false},
            {false,false,false,false,false,true ,false,true ,false,true ,false,false,false,true ,false,true ,false,true ,false,false,false,false,false,true ,false,true ,false,true ,false},
            {false,true ,false,true ,true ,true ,false,true ,false,true ,true ,true ,false,true ,false,true ,false,true ,false,true ,true ,true ,true ,true ,false,true ,false,true ,false},
            {false,true ,false,true ,false,false,false,false,false,false,false,true ,false,false,false,true ,false,true ,false,true ,false,true ,false,false,false,true ,false,true ,false},
            {true,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,true ,false,true ,true ,true ,false,true ,true ,true ,false,true ,true ,true ,true },
            {true ,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,true }
        };
    }
}
