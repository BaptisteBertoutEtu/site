package main.java.fr.univlille.model.entity;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import fr.univlille.iutinfo.cam.player.hunter.IHunterStrategy;
import fr.univlille.iutinfo.cam.player.perception.ICellEvent;
import fr.univlille.iutinfo.cam.player.perception.ICoordinate;
import main.java.fr.univlille.model.cell.Coordinate;

public class IAHunter implements IHunterStrategy{

    private Map<Coordinate,Integer> pathDiscover  = new HashMap<>();
    private int width;
    private int length;
    private int currentTurn;

    @Override
    public ICoordinate play() {
        Coordinate coord = new Coordinate(new Random(width).nextInt(length), new Random(length).nextInt());
        pathDiscover.put(coord, currentTurn);
        return coord;
    }

    @Override
    public void update(ICellEvent arg0) {
        currentTurn++;
    }

    @Override
    public void initialize(int arg0, int arg1) {
        currentTurn = 1;
        this.width = arg0;
        this.length = arg1;
    }
    
}
