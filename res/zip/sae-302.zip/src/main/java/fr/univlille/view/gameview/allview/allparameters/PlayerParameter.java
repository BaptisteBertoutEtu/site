package main.java.fr.univlille.view.gameview.allview.allparameters;

import javafx.geometry.Pos;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import main.java.fr.univlille.model.parameters.Parameters;
import main.java.fr.univlille.utils.OftenUse;

public class PlayerParameter extends VBox{

    private Parameters para;
    private static final String IA = "IA";
    private static final String PLAYER = "PLAYER";

    /**
     * Constructeur de la classe {@link MovementParameter} permettant de construire la vue.
     * @param para L'objet {@link Parameters} permettant de mettre à jour les paramètres du jeu.
     */
    public PlayerParameter(Parameters para){
        this.para=para;
        this.start();
    }   

    
    /**
     * Méthode {@code start} permettant la construction de l'affichage la vue pour changer les paramètres de mouvements dans le labyrinthe.<br>
     */
    public void start(){

        Label explcationMouvLabel = new Label("Ici vous pouvez choisir le mode de jeu voulu.");

        explcationMouvLabel.setFont(OftenUse.FONT_FOR_PARAMETERSVIEW);

        Label choice1 = new Label("Joueur n°1 : ");
        choice1.setFont(OftenUse.FONT_FOR_PARAMETERSVIEW);
        Label choice2 = new Label("Joueur n°2 : ");
        choice2.setFont(OftenUse.FONT_FOR_PARAMETERSVIEW);

        ChoiceBox<String> ch1 = new ChoiceBox<>();
        ch1.getItems().addAll(PLAYER,IA);

        ChoiceBox<String> ch2 = new ChoiceBox<>();
        ch2.getItems().addAll(PLAYER,IA);

        HBox h1 = new HBox(choice1, ch1);
        h1.setAlignment(Pos.CENTER);

        HBox h2 = new HBox(choice2, ch2);
        h2.setAlignment(Pos.CENTER);

        ch1.setOnAction( e -> this.para.setPlayerOne(ch1.getSelectionModel().selectedIndexProperty().intValue()));

        ch2.setOnAction( e -> this.para.setPlayerTwo(ch2.getSelectionModel().selectedIndexProperty().intValue()));


        this.getChildren().addAll(explcationMouvLabel, h1, h2);
        this.setAlignment(Pos.CENTER);
    }
}
