package main.java.fr.univlille.view.gameview.allview.otherview;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import main.java.fr.univlille.model.Game;
import main.java.fr.univlille.model.entity.Hunter;import main.java.fr.univlille.utils.OftenUse;
import main.java.fr.univlille.view.entity.HunterView;
import main.java.fr.univlille.view.gameview.AllViewEnum;
import main.java.fr.univlille.view.gameview.allview.MainView;
import main.java.fr.univlille.view.gameview.allview.View;

public class NameView extends View{
    private Scene s ;
    private static final double WIDTH = MainView.bounds.getWidth();
    private static final double HEIGHT = MainView.bounds.getHeight();
    private static final String TITLE = "Prenom";  


    /**
     * Constructeur de la classe {@link HunterView} qui permet de construire l'affichage de la vue du Chasseur.
     * 
     * @param hunter Le Chasseur lié à sa vue.
     * @see Hunter
     */
    public NameView(){
        this.start();
    }
    @Override
    public Scene getMyScene() {
        return this.s;
    }

    @Override
    public String getTitle() {
        return NameView.TITLE;
    }

    public void start(){
        BorderPane bp = new BorderPane();
        bp.setPrefSize(NameView.WIDTH, NameView.HEIGHT);

        Label title = new Label("Choisissez vos prénoms");
        title.setFont(OftenUse.FONT_FOR_TITLE);

        Label monstre = new Label("Monstre");
        monstre.setFont(OftenUse.FONT_FOR_PARAMETERSVIEW);

        Label hunter = new Label("Chasseur");
        hunter.setFont(OftenUse.FONT_FOR_PARAMETERSVIEW);

        TextField nameMonstre = new TextField();
        TextField nameHunter = new TextField();

        VBox all = new VBox();
        all.setAlignment(Pos.CENTER);
        HBox hValid = new HBox();
        hValid.setAlignment(Pos.CENTER);
        HBox v = new HBox();
        v.setAlignment(Pos.CENTER);
        VBox h1 = new VBox();
        h1.setAlignment(Pos.CENTER);
        h1.getChildren().addAll(monstre, nameMonstre);
        VBox h2 = new VBox();
        h2.setAlignment(Pos.CENTER);
        h2.getChildren().addAll(hunter, nameHunter);
        v.getChildren().addAll(h1,h2);

        
        Button b = new Button("Sortir");
        b.setFont(OftenUse.FONT_FOR_BUTTON);
        
        Button valid = new Button("Valider");
        valid.setFont(OftenUse.FONT_FOR_BUTTON);
        hValid.getChildren().add(valid);
        
        all.getChildren().addAll(v,hValid);
        
        HBox h = new HBox();
        h.setAlignment(Pos.CENTER);
        h.getChildren().addAll(b);

        bp.setTop(title);
        bp.setCenter(all);
        bp.setBottom(h);
        BorderPane.setAlignment(title, Pos.CENTER);

        valid.setOnAction(e -> {
            Game.nameHunter = nameHunter.getText();
            Game.nameMonster = nameMonstre.getText();
            notifyObservers(AllViewEnum.NAMEVIEW);
        });
        
        b.setOnAction(e -> notifyObservers());
        
        s = new Scene(bp);
    }
}
