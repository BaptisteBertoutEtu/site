# Sprint 0

## Démo + Planification du sprint suivant

### Ce que nous avons fait durant ce sprint
- Choix du thème et du slogan
- Choix du nom du jeu
- Séparation des backlog

### Ce que nous allons faire durant le prochain sprint
- Ecran d'accueil 
- Bestiaire numéro 1
- L'architecture git

## Rétrospective

### Sur quoi avons nous butté ?
Découpage des backlog un peu fastidieux
Débat et choix un peu long

### PDCA
Amélioration : Faire un vote romain
