# Sprint 1

## Démo + Planification du sprint suivant

### Ce que nous avons fait durant ce sprint
- Ecran d'accueil
- Bestiaire numéro 1
- L'architecture git

### Ce que nous allons faire durant le prochain sprint
- Bestiaire numéro 2
- Bestiaire numéro 3
- Définir Renaud 
- Sprite bestiaire 1 et 2

## Rétrospective

### Sur quoi avons nous butté ?
Bug de mise en commun entre le bestiaire et l'écran d'accueil

### PDCA
Amelioration : Ecrire un test de mise en commun avant l'écriture de nos autre classes.
