# Sprint 2

## Démo + Planification du sprint suivant

### Ce que nous avons fait durant ce sprint
- Bestiaire numéro 2
- Bestiaire numéro 3
- Définir Renaud 
- Sprite bestiaire 1 et 2

### Ce que nous allons faire durant le prochain sprint
- Implémentation des monstres
- Bestaire numéro 4
- Implémentation du bestiaire 
- Description boss final

## Rétrospective

### Sur quoi avons nous butté ?
- Rien pour ce sprint

### PDCA

