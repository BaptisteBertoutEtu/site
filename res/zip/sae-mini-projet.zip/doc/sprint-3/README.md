# Sprint 3

## Démo + Planification du sprint suivant

### Ce que nous avons fait durant ce sprint
- Bestiaire numéro 4 et 5
- Définir Renaud
- Implémentation des sorts des monstres 
- Sprite bestiaire 3,4 et 5
- Implémentation des salles
- commencement de l'implémentation du système de combat

### Ce que nous allons faire durant le prochain sprint
- Implémentation du bestiaire 
- Trouver un sprite pour Renaud
- Création et implémentation des sorts de Renaud
- Finir l'implémentation du sytème de combat et de déplacements.

## Rétrospective

### Sur quoi avons nous butté ?
- Trouver des sprites représentatif de chaque monstres.

### PDCA
Amélioration : Inventer des monstres plus accesible au niveau de l'ASCII art.
