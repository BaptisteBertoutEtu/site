# Sprint 4

## Démo + Planification du sprint suivant

### Ce que nous avons fait durant ce sprint
- Fini le mapping
- Commencer l'interface utilisateur
- Inventé les sorts fixes et scale de Renaud
- Trouver un sprite pour renaud
- Fini l'implémentation du bestiaire

### Ce que nous allons faire durant le prochain sprint
- Continuer l'interface utilisateur
- Implémenter les sorts fixes et scale
- Dev le Lore
- Finir le système de combat
- Finir les système de déplcement

## Rétrospective

### Sur quoi avons nous butté ?
- Rien pour ce sprint

### PDCA

