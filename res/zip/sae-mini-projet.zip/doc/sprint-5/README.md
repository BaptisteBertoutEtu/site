# Sprint 5

## Démo + Planification du sprint suivant

### Ce que nous avons fait durant ce sprint
- Interface utilisateur avec l'affichage du personnage principal et l'ennemi.
- Finit le système de combat
- Continuer le système de déplacement
- Finit le système des sorts et sorts de scaling
- Développer le lore

### Ce que nous allons faire durant le prochain sprint
- Continuer l'interface utilisateur avec l'affichage des points de vie des personnages.
- Finir les système de déplacement

## Rétrospective

### Sur quoi avons nous butté ?
- l'affichage des sprites des personnages.

### PDCA
Amélioration : Réfléchir a comment nous allons les utiliser/afficher avant de les choisir.
