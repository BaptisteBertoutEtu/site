# Sprint 6

## Démo + Planification du sprint suivant

### Ce que nous avons fait durant ce sprint
- Finit l'interface utilisateur et la relier avec le système de combat.
- Fini de cerner le lore.
- Level up & choix de sorts fini.
- Lier déplacements, le donjon et le bestaire.

### Ce que nous allons faire durant le prochain sprint
- commencer à écrire les conseils pour les salles de conseil.
- Revoir la méthode de calcul des dégâts.
- Correction des fautes du lore.
- Implémentation du système d'attaque.

## Rétrospective

### Sur quoi avons nous butté ?
- le debug du système de combat. 

### PDCA
Amélioration : Ecrire la class de test pour le système de combat avant de d'écrire cette même class.
