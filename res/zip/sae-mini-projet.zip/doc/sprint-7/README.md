# Sprint 7

## Démo + Planification du sprint suivant

### Ce que nous avons fait durant ce sprint
- Les conseils pour la salle de conseil fini.
- Les calculs de dégâts ont été fixés.
- Faute d'orthographe du lore corrigés.
- Commencer les tests unitaires pour les méthodes de classe de Renaud.

### Ce que nous allons faire durant le prochain sprint
- Equilibrage du jeu.
- Tests unitaire Battle.
- Tests unitaire Bonus. 

## Rétrospective

### Sur quoi avons nous butté ?
- Tests unitaire de Renaud certaine méthodes appelaient d'autre méthodes qui n'étaient pas testable 

### PDCA

