# Sprint 8

## Démo + Planification du sprint suivant

### Ce que nous avons fait durant ce sprint
- Equilibrage du jeu fini.
- Ecran de fin et de victoire.
- Ajout des dialogues de l'histoire.
- Test unitaire de Renaud fini.
- Ajout d'une barre de statistiques du personnage Renaud.
- Ajout d'un tag sur la version gitlab du jeu fonctionnel.

### Ce que nous allons faire durant le prochain sprint
- Corriger les fautes d'orthographe restantes. 
- Tenter d'ajouter des couleurs au jeu. 
- Reflexion sur l'ajout d'un mode sans fin.

## Rétrospective

### Sur quoi avons nous butté ?
- l'equilibrage du jeu soit trop dur soit trop compliqué.

### PDCA

