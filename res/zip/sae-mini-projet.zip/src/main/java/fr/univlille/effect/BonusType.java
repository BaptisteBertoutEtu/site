package fr.univlille.effect;

public enum BonusType {
    BUFF,
    SPELL_SCALING,
    SPELL
}
