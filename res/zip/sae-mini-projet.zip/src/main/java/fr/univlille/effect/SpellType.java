package fr.univlille.effect;

public enum SpellType {
    HEALTH,
    ATTACK,
    DEFENSE
}
