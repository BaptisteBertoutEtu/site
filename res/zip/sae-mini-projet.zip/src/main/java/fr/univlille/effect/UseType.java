package fr.univlille.effect;

public enum UseType {
    DAMAGE,
    HEAL
}
